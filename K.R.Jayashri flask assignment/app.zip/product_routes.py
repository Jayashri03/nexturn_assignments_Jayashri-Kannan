from flask import Blueprint, render_template, request, redirect, url_for

product_routes = Blueprint('product_routes', __name__)

# In-memory list to store products
products = []
# Sample product list for demonstration
products = [
    {'id': 1, 'name': 'Product A', 'price': 10.99},
    {'id': 2, 'name': 'Product B', 'price': 12.99},
    {'id': 3, 'name': 'Product C', 'price': 15.49}
]

 # Initialize a variable to keep track of the next product ID

# Function to retrieve the list of products
def get_products():
    return products

# Route to display the list of products
@product_routes.route('/products')
def index():
    return render_template('index.html', products=get_products())

# Route to create a new product
@product_routes.route('/products/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        new_product = {
            'id': request.form['ID'],  # Use the ID provided by the user
            'name': request.form['name'],
            'price': float(request.form['price'])  # Convert price to float
        }
        # Check if ID is unique
        if any(product['id'] == new_product['id'] for product in products):
            return "Product ID must be unique", 400  # Error if ID already exists
        
        products.append(new_product)
        return redirect(url_for('product_routes.index'))  # Redirect to the product list
    return render_template('create_product.html', title='Create Product')

# Initialize products (Make sure this is defined at the top level)
print(products)

@product_routes.route('/products/update/<int:product_id>', methods=['GET', 'POST'])
def update(product_id):
    # Search for the product by ID
    product = next((p for p in products if int(p['id']) == product_id), None)
    
    if product:
        if request.method == 'POST':
            # Only update the name and price, ID remains unchanged
            product['name'] = request.form['name']
            product['price'] = float(request.form['price'])
            return redirect('/products')  # Redirect to the product list

        # Pass the product and product_id to the template
        return render_template('update.html', product=product, product_id=product_id)
    else:
        return "Product not found", 404  # Handle product not found

@product_routes.route('/products/delete/<int:product_id>', methods=['POST'])
def delete(product_id):
    if product_id <= len(products) and product_id > 0:
        del products[product_id - 1]  # Delete the product from the list
        return redirect('/products')  # Redirect to the product list after deletion
    else:
        return "Product not found", 404


