from flask import Blueprint, request, render_template, redirect

category_routes = Blueprint('category_routes', __name__)

categories = []  

@category_routes.route('/categories')
def index():
    return render_template('categories.html', categories=categories)


@category_routes.route('/categories/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        new_category = {
            'id': len(categories) + 1, 
            'name': request.form['name']
        }
        categories.append(new_category)
        return redirect('/categories')
    return render_template('create_category.html')


@category_routes.route('/categories/update/<int:category_id>', methods=['GET', 'POST'])
def update(category_id):
    if category_id <= len(categories) and category_id > 0:
        if request.method == 'POST':
            categories[category_id - 1]['name'] = request.form['name'] 
            return redirect('/categories')
        return render_template('update_category.html', category=categories[category_id - 1])
    else:
        return "Category do not exist", 404


@category_routes.route('/categories/delete/<int:category_id>', methods=['POST'])
def delete(category_id):
    if category_id <= len(categories) and category_id > 0:
        categories.pop(category_id - 1) 
        return redirect('/categories')
    else:
        return "Category do not exist", 404
