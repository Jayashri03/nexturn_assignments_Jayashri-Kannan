from flask import Flask
from .routes import main_routes
from .product_routes import product_routes
from .category_routes import category_routes

def create_app():
    app = Flask(__name__)

    # Register blueprints
    app.register_blueprint(main_routes)
    app.register_blueprint(product_routes)
    app.register_blueprint(category_routes)

    return app
